<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-LEARNING</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="responsive.css">

    <link rel="icon" type="image/x-icon" href="image/logo.png">
</head>
<body>
    

      
      <header class="head-sec" id="head-sec">
        <!-------------------- navbar section ------------------------->
        <nav class="navbar navbar-expand-lg navbar-light sticky-top">
          <div class="container-fluid">
            <img src="image/logo.png" alt="logo" class="img-fluid nav-logo">
            <a class="navbar-brand me-auto" href="#">Learning</a>
        
            <!-- Mobile Dark Mode Button (only visible on mobile) -->
            <div class="d-flex align-items-center d-lg-none me-2 mt-0">
              <button class="drk-btn dark-toggle-btn" id="drk-btn" type="button" onclick="dark_mode_x()">
                <i class="fa-regular fa-moon pt-2"></i>
              </button>
            </div>

        
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
              aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
        
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav m-auto mb-2 gap-5 mb-lg-0 pe-5">
                <li class="nav-item">
                  <a class="nav-link active" id="home-btn" aria-current="page" href="#home">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" id="blog_btn" href="#">Blog</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="#About">About</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="login.php">Profile</a>
                </li>
                <!-- <li class="nav-item">
                  <a class="nav-link active" href="login.php">Log in</a>
                </li>
                <li>
                  <a class="nav-link active" href="signup.php">Sing Up</a>
                </li> -->
              </ul>
        


              
              <div class="dark-mode-btn d-none d-sm-none d-lg-flex align-items-center me-3">
                <button class="drk-btn dark-toggle-btn" id="drk-btn-desktop" type="button" onclick="dark_mode_x()">
                  <i class="fa-regular fa-moon pt-2"></i>
                </button>
              </div>
        
              <form class="d-flex">
                <input id="inpt" class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-dark" id="search-btn" type="submit">
                  <i class="fa-solid fa-magnifying-glass mt-2"></i>
                </button>
              </form>
            </div>
          </div>
        </nav>
        
        
        <!-------------- top-section ----------------->
        <section id="home">
          <section id="home-sec">
            <div class="top-sections mt-3 row d-flex justify-content-center gap-5 m-3">
              <div class="lft-sec  p-4 col-lg-2 col-md-12 col-sm-12 box box1 m-2" id="lft-sec">
                <div class="ref-sec">
                  <h2> Refarence <i class="fa-solid fa-cloud fa-beat-fade"></i></h2>
                  <hr class="my-4 border-3 border-dark">
                  <div class="btns" id="ref-itms">
                    <button class="btn btn w-100  mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> HTML basics</button>
                    <button class="btn btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> CSS basics</button>
                    <button class="btn btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript basics</button>
                    <button class="btn btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> Java OOP</button>
                    <button class="btn btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> Python basics</button>
                    <button class="btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    <button class="btn w-100 mt-2 p-2"><i class="fa-solid fa-arrow-up-right-from-square "></i> JavaScript object basics</button>
                    
                  </div>
                </div>
              </div>
              <div class="mid-sec   p-4 col-lg-6 col-md-12 col-sm-12 box mt-2" id="mid-sec">
                <div class="sec1 inr-sec">
                  <h1>HTML</h1>
                  <h3>Structuring the web with HTML <i class="fa-brands fa-html5 fa-beat-fade"></i></h3>
                  <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta rem maiores, iusto nobis delectus nam distinctio voluptas quidem molestias, exercitationem ipsam dolores sed aliquam culpa reiciendis mollitia, veritatis necessitatibus beatae.</p>
                  <div class="more-info d-flex justify-content-evenly gap-3  text-center">
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/Introduction-To-HTML.jpg" alt="Introduction-To-HTML" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                    <a href="" class="info-link">
                      <div class="info-cart cart1" id="cart1">
                        <img src="image/Introduction-To-HTML.jpg" alt="Introduction-To-HTML" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/Introduction-To-HTML.jpg" alt="Introduction-To-HTML" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                  </div>
                </div>
                
                <!--------------------- mid-section-part-2 -------------->
                <div class="sec2 inr-sec mt-5">
                  <h1>CSS</h1>
                  <h3>Styling the web with HTML <i class="fa-brands fa-css3-alt fa-beat-fade"></i></h3>
                  <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta rem maiores, iusto nobis delectus nam distinctio voluptas quidem molestias, exercitationem ipsam dolores sed aliquam culpa reiciendis mollitia, veritatis necessitatibus beatae.</p>
                  <div class="more-info d-flex justify-content-evenly gap-3  text-center">
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/css1.png" alt="CSS-Tutorial.png" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/css1.png" alt="CSS-Tutorial.png" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/css1.png" alt="CSS-Tutorial.png" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                  </div>
                </div>
                <!--------------------- mid-section-part-3 -------------->
                <div class="sec2 inr-sec mt-5">
                  <h1>JAVA</h1>
                  <h3>Make web pages interactive and dynamic <i class="fa-brands fa-square-js fa-beat-fade"></i></h3>
                  <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta rem maiores, iusto nobis delectus nam distinctio voluptas quidem molestias, exercitationem ipsam dolores sed aliquam culpa reiciendis mollitia, veritatis necessitatibus beatae.</p>
                  <div class="more-info d-flex justify-content-evenly gap-3  text-center">
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/js3.png" alt="js.png" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/js2.png" alt="js2.png" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                    <a href="" class="info-link">
                      <div class="info-cart cart1">
                        <img src="image/js.png" alt="js3.png" class="img-fluid">
                        <p class="mt-3">Click Here To Read More</p>
                      </div>
                    </a>
                    
                  </div>
                </div>
                
                
                
                
                
                
                
                
                
                
              </div>
            
              <div class="rght-sec  p-4 col-lg-3 col-md-12 col-sm-12 box p-2 m-2">
                <h2>Watch Videos <i class="fa-solid fa-circle-play fa-beat-fade"></i></h2>
                <hr class="my-4 border-3 border-dark">
                <div class="video">

                  <iframe width="93%" height="240px" src="https://www.youtube.com/embed/kUMe1FH4CHE?si=Do5rLHQp_EaVJnbc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"allowfullscreen> </iframe>
                  <p class="mt-3">
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores esse vitae dolore
                      reiciendis
                      aut ipsa sunt neque vero.
                  </p>
                </div>
                <div class="video">
                  <iframe width="93%" height="240px" src="https://www.youtube.com/embed/OXGznpKZ_sA?si=kOmMaYzQaC7s-B49" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"allowfullscreen> </iframe>
                  <p class="mt-3">
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores esse vitae dolore
                      reiciendis
                      aut ipsa sunt neque vero.
                  </p>
                </div>
                <div class="video">
                  <iframe width="93%" height="240px" src="https://www.youtube.com/embed/PkZNo7MFNFg?si=dktHUJuvNjJtWix2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"allowfullscreen> </iframe>
                  <p class="mt-3">
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores esse vitae dolore
                      reiciendis
                      aut ipsa sunt neque vero.
                  </p>
                </div>



              </div> 
            


            </div>
          </section>
        

          <section id="blog-sec" class="container text-center pt-5">
              <div class="blg-itms bg-danger p-5">

                <div class="blg-sec-ttle d-flex justify-content-between">
                  <div class="pt1 my-auto text-start">
                    <h1>Blogs📃</h1>
                    <p>Here you can found all the blogs</p>
                  </div>
                  <div class="pt2">
                    <a href=""><img src="image/blog-header_480.png" class="img-fluid w-50 blg-img" alt=""></a>
                  </div>
                </div>
                <hr class="my-4 border-3 border-dark">

                <div class="blg-cards d-flex gap-5 flex-wrap justify-content-center">
                  <div class="card" style="width: 18rem;">
                    <div class="card-img-div bg-image hover-zoom">
                      <img class="card-img-top" src="image/CSS-Tutorial.png" alt="Card image cap">
                    </div>
                    <div class="card-body p-3">
                      <h3 class="card-title">New to the web platform in April</h3>
                      <p class="card-text pt-3">Discover some of the interesting features that have landed in stable and beta web browsers during April 2025.</p>
                      <button class="btn btn-tag border p-1">html</button>
                      <button class="btn btn-tag border p-1">css</button>
                      <button class="btn btn-tag border p-1">JavaScript</button>
                      <br><br>
                      <a href="#" class="btn btn-primary">Read Blog</a>
                    </div>
                  </div>
                  

                  <div class="card" style="width: 18rem;">
                    <div class="card-img-div bg-image hover-zoom">
                      <img class="card-img-top" src="image/CSS-Tutorial.png" alt="Card image cap">
                    </div>
                    <div class="card-body p-3">
                      <h3 class="card-title">New to the web platform in April</h3>
                      <p class="card-text pt-3">Discover some of the interesting features that have landed in stable and beta web browsers during April 2025.</p>
                      <button class="btn btn-tag border p-1">html</button>
                      <button class="btn btn-tag border p-1">css</button>
                      <button class="btn btn-tag border p-1">JavaScript</button>
                      <br><br>
                      <a href="#" class="btn btn-primary">Read Blog</a>
                    </div>
                  </div>

                  <div class="card" style="width: 18rem;">
                    <div class="card-img-div bg-image hover-zoom">
                      <img class="card-img-top" src="image/CSS-Tutorial.png" alt="Card image cap">
                    </div>
                    <div class="card-body p-3">
                      <h3 class="card-title">New to the web platform in April</h3>
                      <p class="card-text pt-3">Discover some of the interesting features that have landed in stable and beta web browsers during April 2025.</p>
                      <button class="btn btn-tag border p-1">html</button>
                      <button class="btn btn-tag border p-1">css</button>
                      <button class="btn btn-tag border p-1">JavaScript</button>
                      <br><br>
                      <a href="#" class="btn btn-primary">Read Blog</a>
                    </div>
                  </div>

                  <div class="card" style="width: 18rem;">
                    <div class="card-img-div bg-image hover-zoom">
                      <img class="card-img-top" src="image/CSS-Tutorial.png" alt="Card image cap">
                    </div>
                    <div class="card-body p-3">
                      <h3 class="card-title">New to the web platform in April</h3>
                      <p class="card-text pt-3">Discover some of the interesting features that have landed in stable and beta web browsers during April 2025.</p>
                      <button class="btn btn-tag border p-1">html</button>
                      <button class="btn btn-tag border p-1">css</button>
                      <button class="btn btn-tag border p-1">JavaScript</button>
                      <br><br>
                      <a href="#" class="btn btn-primary">Read Blog</a>
                    </div>
                  </div>

                  <div class="card" style="width: 18rem;">
                    <div class="card-img-div bg-image hover-zoom">
                      <img class="card-img-top" src="image/CSS-Tutorial.png" alt="Card image cap">
                    </div>
                    <div class="card-body p-3">
                      <h3 class="card-title">New to the web platform in April</h3>
                      <p class="card-text pt-3">Discover some of the interesting features that have landed in stable and beta web browsers during April 2025.</p>
                      <button class="btn btn-tag border p-1">html</button>
                      <button class="btn btn-tag border p-1">css</button>
                      <button class="btn btn-tag border p-1">JavaScript</button>
                      <br><br>
                      <a href="#" class="btn btn-primary">Read Blog</a>
                    </div>
                  </div>


                  <div class="card" style="width: 18rem;">
                    <div class="card-img-div bg-image hover-zoom">
                      <img class="card-img-top" src="image/CSS-Tutorial.png" alt="Card image cap">
                    </div>
                    <div class="card-body p-3">
                      <h3 class="card-title">New to the web platform in April</h3>
                      <p class="card-text pt-3">Discover some of the interesting features that have landed in stable and beta web browsers during April 2025.</p>
                      <button class="btn btn-tag border p-1">html</button>
                      <button class="btn btn-tag border p-1">css</button>
                      <button class="btn btn-tag border p-1">JavaScript</button>
                      <br><br>
                      <a href="#" class="btn btn-primary">Read Blog</a>
                    </div>
                  </div>
                  



                  
                  
                  
                  




                </div>


              </div>

          </section>
        </section>



        <section class="footer mt-5" id="About">
          <footer class="text-center text-lg-start bg-body-danger text-dark">
    
            <section class=" pt-3">
              <div class="container text-center text-md-start mt-5">
                <div class="row mt-3">
                  <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4 text-center">
                    <h6 class="text-uppercase fw-bold mb-4">
                      <i class="fas fa-gem"></i> E-LEARNING</h6>
                      <hr class="my-4 border-3 border-dark">
                    <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus voluptatem aut mollitia obcaecati doloribus repellat optio quae maxime veniam qui!
                    </p>
                  </div>
    
                  <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4 text-center">
                    <h6 class="text-uppercase fw-bold mb-4">Products</h6>
                    <hr class="my-4 border-3 border-dark">
                    <p><a href="#!" class="text-reset">Kapsalon</a></p>
                    <p><a href="#!" class="text-reset">Burek</a></p>
                    <p><a href="#!" class="text-reset">Vue</a></p>
                    <p><a href="#!" class="text-reset">Flamiche</a></p>
                  </div>
    
                  <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4 text-center">
                    <h6 class="text-uppercase fw-bold mb-4">Useful links</h6>
                    <hr class="my-4 border-3 border-dark">
                    <p><a href="#" target="_blank" class="text-reset text-decoration-none"><i class="fa-brands fa-facebook"></i> Facebook</a></p>
                    <p><a href="#" target="_blank" class="text-reset text-decoration-none"><i class="fa-brands fa-instagram"></i> Instagram</a></p>
                    <p><a href="#" target="_blank" class="text-reset text-decoration-none"><i class="fa-brands fa-github"></i> Github</a></p>
                    <p><a href="#" target="_blank" class="text-reset text-decoration-none"><i class="fa-brands fa-x-twitter"></i> X-Twitter</a></p>
                    
                    
                  </div>
    
                  <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4 text-center">
                    <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                    <hr class="my-4 border-3 border-dark">
                    <p><i class="fas fa-home"></i> New York, US</p>
                    <p>
                      <i class="fas fa-envelope "></i>
                      info@elearning.com
                    </p>
                    <p><i class="fas fa-phone "></i> + 01 234 567 88</p>
                    <p><i class="fas fa-print "></i> + 01 234 567 89</p>
                  </div>
                </div>
              </div>
            </section>
    
            <div class="text-center cpy-rgt p-4 " style="background-color: rgba(0, 0, 0, 0.1);">
              © 2025 Copyright:
              <a class="text-reset fw-bold" target="_blank" href="https://github.com/Andrew-Velox">Andrew-Velox</a>
            </div>
          </footer>
        </section>
      </header>



      
      
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.fog.min.js"></script>
      <script src="app.js"></script>
      <!-- <script>
        vantaEffect = VANTA.FOG({
          el: ".head-sec",
          mouseControls: true,
          touchControls: true,
          gyroControls: false,
          minHeight: 200.00,
          minWidth: 200.00,
          scale: 1.00,
          scaleMobile: 1.00
        }) -->
        
      </script>
</body>
</html>