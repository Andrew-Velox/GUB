<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - E-Learning Platform</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #e6f0fa;
            margin: 0;
        }
        .navbar {
            background-color: #fff;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .navbar ul {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: flex-end;
            margin: 0;
        }
        .nav-item {
            margin-left: 20px;
        }
        .nav-link {
            text-decoration: none;
            color: #2563eb;
            font-weight: bold;
            font-size: 16px;
        }
        .nav-link:hover {
            color: #1e40af;
        }
        .profile-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .profile-container h1 {
            color: #1e3a8a;
            text-align: center;
        }
        .profile-container h2 {
            color: #1e3a8a;
            font-size: 24px;
            margin-top: 20px;
        }
        .course-list {
            margin-top: 20px;
        }
        .course-item {
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: #f9fafb;
        }
        .course-item h3 {
            margin: 0;
            font-size: 18px;
            color: #2563eb;
        }
        .course-item p {
            margin: 5px 0 0;
            color: #4b5563;
        }
        .error {
            color: #dc2626;
            text-align: center;
            margin: 20px 0;
        }
        .usr-image {
            display: block;
            margin: auto;
            width: 300px;
            height: 300px; 
            object-fit: cover; 
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <ul>
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Log out</a>
            </li>
        </ul>
    </nav>
    <div class="profile-container">
        <?php
        session_start();
        if (!isset($_SESSION['username'])) {
            echo "<p class='error'>Please log in to view your profile.</p>";
            echo "<p style='text-align: center;'><a href='login.php' style='color: #2563eb; text-decoration: none;'>Log in</a></p>";
            exit();
        }

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "myproject";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $input_username = $_SESSION['username'];
        $stmt = $conn->prepare("SELECT full_name, email, role FROM users WHERE username = ?");
        $stmt->bind_param("s", $input_username);
        $stmt->execute();
        $stmt->bind_result($full_name, $email, $role);
        $stmt->fetch();
        $stmt->close();
        $conn->close();
        ?>
        <img src="image/Kaneki_ken.gif" alt="" class="usr-image">
        <h1>Welcome, <?php echo htmlspecialchars($full_name); ?>!</h1>
        <div class="profile-info">
            <p><strong>Username:</strong> <?php echo htmlspecialchars($input_username); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            <p><strong>Role:</strong> <?php echo htmlspecialchars($role); ?></p>
        </div>
        <h2>Your Enrolled Courses</h2>
        <div class="course-list">
            <div class="course-item">
                <h3>Introduction to Programming</h3>
                <p>Progress: 60% | Instructor: Dr. Smith</p>
            </div>
            <div class="course-item">
                <h3>Web Development Basics</h3>
                <p>Progress: 25% | Instructor: Prof. Johnson</p>
            </div>
        </div>
        <h2>Your Progress</h2>
        <p>Track your learning journey and explore more courses to enhance your skills!</p>
    </div>
</body>
</html>