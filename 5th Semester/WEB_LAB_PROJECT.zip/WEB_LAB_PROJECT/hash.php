<?php
echo password_hash('1111', PASSWORD_DEFAULT);
?>