<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - E-Learning Platform</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #e6f0fa;
        }
        .signup-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 320px;
        }
        .signup-container h2 {
            text-align: center;
            color: #1e3a8a;
        }
        .signup-container input, .signup-container select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #d1d5db;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .signup-container button {
            width: 100%;
            padding: 10px;
            background-color: #2563eb;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        .signup-container button:hover {
            background-color: #1e40af;
        }
        .error, .success {
            text-align: center;
            margin: 10px 0;
        }
        .error {
            color: #dc2626;
        }
        .success {
            color: #16a34a;
        }
        .login-link {
            text-align: center;
            margin-top: 10px;
        }
        .login-link a {
            color: #2563eb;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Sign Up</h2>
        <?php
        session_start();
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "myproject";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $input_username = $_POST['username'];
            $input_email = $_POST['email'];
            $input_full_name = $_POST['full_name'];
            $input_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $input_role = $_POST['role'];

            // Check if username or email already exists
            $check_stmt = $conn->prepare("SELECT username, email FROM users WHERE username = ? OR email = ?");
            $check_stmt->bind_param("ss", $input_username, $input_email);
            $check_stmt->execute();
            $check_stmt->store_result();

            if ($check_stmt->num_rows > 0) {
                $check_stmt->bind_result($existing_username, $existing_email);
                $check_stmt->fetch();
                if ($existing_username === $input_username) {
                    echo "<p class='error'>Error: Username '$input_username' is already taken.</p>";
                } elseif ($existing_email === $input_email) {
                    echo "<p class='error'>Error: Email '$input_email' is already in use.</p>";
                }
            } else {
                $stmt = $conn->prepare("INSERT INTO users (username, email, full_name, password, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $input_username, $input_email, $input_full_name, $input_password, $input_role);

                if ($stmt->execute()) {
                    $_SESSION['username'] = $input_username;
                    header("Location: profile.php");
                    exit();
                } else {
                    echo "<p class='error'>Error: Could not sign up. Please try again.</p>";
                }
                $stmt->close();
            }

            $check_stmt->close();
            $conn->close();
        }
        ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role" required>
                <option value="Student">Student</option>
                <option value="Instructor">Instructor</option>
            </select>
            <button type="submit">Sign Up</button>
        </form>
        <p class="login-link">Already have an account? <a href="login.php">Log in</a></p>
    </div>
</body>
</html>